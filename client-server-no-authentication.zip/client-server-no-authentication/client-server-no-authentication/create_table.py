import sqlite3

conn = sqlite3.connect('test.db')
c = conn.cursor()
c.execute(''' CREATE TABLE users (uname,upass) ''')

c.execute("INSERT INTO users(uname,upass) VALUES ('a','a'),('b','b')")

conn.commit()

conn.close()