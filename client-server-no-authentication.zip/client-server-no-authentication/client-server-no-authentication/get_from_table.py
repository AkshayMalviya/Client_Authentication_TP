import sqlite3

class AuthenticateUser:
	def __init__(self,uname,upass):
		self.uname = uname
		self.upass = upass
	def validate_user(self):		
		conn = sqlite3.connect('test.db')
		conn.row_factory = sqlite3.Row
		c = conn.cursor()		
		rr = c.execute('SELECT * FROM users where uname = ? and upass = ? LIMIT 1',(self.uname,self.upass))
		data_retruned = False
		for row in rr:	
			data_retruned = True
			print(row[0])

		return data_retruned

		# print(c.rowcount)
		# print(dir(r))